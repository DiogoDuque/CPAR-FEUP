====== Compiling ======

=== LU Shared and Sequential ===
gcc luDecomposition.c -Wall -O3 -fopenmp -o lu

=== Sieve of Eratosthenes Shared and Sequential ===
gcc eratosthenes.c -Wall -O3 -fopenmp -o eratosthenes

=== LU Distributed ===
mpicc luDecompositionDistr.c -Wall -O3 -o luDistr

=== Sieve of Eratosthenes Distributed ===
mpicc eratosthenesDistr.c -Wall -O3 -o eratosthenesDistr



====== Running ======

=== LU Shared and Sequential ===
./lu seq 1000 A_1000x1000.csv
./lu shared 1000 A_1000x1000.csv

=== Sieve of Eratosthenes Shared and Sequential ===
./eratosthenes seq 100000000
/eratosthenes shared 100000000

=== LU Distributed ===
mpirun -n 3 --use-hwthread-cpus luDistr A_1000x1000.csv 1000

=== Sieve of Eratosthenes Distributed ===
mpirun -n 4 --use-hwthread-cpus eratosthenesDistr 100000000
